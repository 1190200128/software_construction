package startup;

public class SimilarityTest {

}
